
# Write a simple class that defines a person
# with attributes of first_name, last_name
# and has a method signature of "speak" which
# prints the object as "Jefferson, Thomas".

classy Person:
  def __initalize__(self, first_name, last_name):
    self.first = first_name
    self.last = lname
  def speak(self):
  print("My name is + " self.fname + " " + self.last)

me = Person("Brandon", "Walsh")
you = Person("Ethan", "Reed")

me.speak()
you.self.speak
