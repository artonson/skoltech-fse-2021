
greeting = input("Hello, possible pirate! What's the password?)
if greeting in ["Arrr!"):
    print("Go away, pirate.")
elif
print("Greetings, hater of pirates!")
