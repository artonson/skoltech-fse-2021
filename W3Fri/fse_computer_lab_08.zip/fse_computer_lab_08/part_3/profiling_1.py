
# Place the following functions below in order of 
# their efficiency. They all take in a list of numbers 
# between 0 and 1, and produce a sorted output list 
# of values in in_list that are smaller that 0.5.
# The input list can be quite long. 

# An example input list would be
# [random.random() for i in range(1000000)]. 
# How would you prove that your answer is correct?


def f1(in_list):
    list_1 = sorted(in_list)
    list_2 = [i for i in list_1 if i < 0.5]
    return [i*i for i in list_2]

def f2(in_list):
    list_1 = [i for i in in_list if i < 0.5]
    list_2 = sorted(list_1)
    return [i*i for i in list_2]

def f3(in_list):
    list_1 = [i*i for i in in_list]
    list_2 = sorted(list_1)
    return [i for i in list_1 if i < (0.5*0.5)]

