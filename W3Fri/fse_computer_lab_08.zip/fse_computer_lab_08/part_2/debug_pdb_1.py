
# The following in an impementation of a Selection Sort
# (https://en.wikipedia.org/wiki/Selection_sort). 
# 

def search_smallest(arr):
    smallest = arr[0]
    smallest_index = 0
    for i in range(1, len(arr)):
        if arr[i] < smallest:
            smallest = arr[i]
            smallest_index = i
    return smallest_index

def selection_sort(arr):
    for i in range(0, len(arr)):
       c = arr[i]
       curr = search_smallest(arr)
       if (c > arr[curr] and curr!=i):
           arr[i] = arr[curr]
           arr[curr] = c
    return arr


import random
in_list = [random.randint(1, 100) for x in range(10)]
print(f'Input list: {in_list}')

out_list = selection_sort(in_list)
print(f'Sorted list: {out_list}')

