#!/bin/bash -x

wget https://github.com/CGAL/cgal/releases/download/releases/CGAL-4.14.1/CGAL-4.14.1.tar.xz \
    && tar -xf CGAL-4.14.1.tar.xz \
    && cd CGAL-4.14.1 && cmake -DCMAKE_INSTALL_PREFIX=.. -DCMAKE_BUILD_TYPE=Release . && make -j 4 && make install && rm ../CGAL-4.14.1.tar.xz
